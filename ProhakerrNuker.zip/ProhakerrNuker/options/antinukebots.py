import discord
from pystyle import Write, Colors

async def search_for_bots(bot, selected_guild):
    user_id_to_name = {
        536991182035746816: "Wick#3938",
        651095740390834176: "Security#1120",
    }

    user_ids_to_search = user_id_to_name.keys()

    guild = selected_guild

    for user_id in user_ids_to_search:
        member = guild.get_member(user_id)
        name = user_id_to_name.get(user_id, "Unknown")

        if member is not None:
            if member.bot:
                Write.Print(f"[{name}]: ✔ (Bot found)\n", Colors.green, interval=0.02)
                try:
                    await member.ban(reason="Nuh uh.")
                    Write.Print(f"✅ Bot '{name}' has been banned.\n", Colors.green, interval=0.02)
                except discord.Forbidden:
                    Write.Print(f"❌ Permission denied: The bot cannot ban '{name}'.\n", Colors.red, interval=0.02)
                except discord.HTTPException as e:
                    Write.Print(f"❌ Failed to ban bot '{name}'. Error: {e}\n", Colors.red, interval=0.02)
            else:
                Write.Print(f"[{name}]: ✘ (Not a bot)\n", Colors.red, interval=0.02)
        else:
            Write.Print(f"[{name}]: ✘ (User not found)\n", Colors.red, interval=0.02)
