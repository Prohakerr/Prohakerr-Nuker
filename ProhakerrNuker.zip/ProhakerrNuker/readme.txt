Put the bot token in the token.txt
Please report any bugs to the discord server: https://discord.gg/ywpuSY8Fp4
If u need a full tutorial here is the yt vid: 


BTW SKID = GAY 